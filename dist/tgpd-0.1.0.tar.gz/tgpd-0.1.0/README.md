<h1 style="text-align: center"> tgpd </h1>

## Install

```shell
pip3 install git+https://github.com/Rhythmicc/tgpd.git -U
```

## Usage

```shell
tgpd --help
```

